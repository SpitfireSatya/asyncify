#!/bin/sh

echo "Not implemented." 1>&2
exit 1
